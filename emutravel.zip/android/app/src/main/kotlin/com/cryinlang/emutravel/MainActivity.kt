package com.cryinlang.emutravel

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
